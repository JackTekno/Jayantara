import 'package:flutter/material.dart';
import '../services/nmap_service.dart';
import 'result_view.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  _HomeViewState createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  final TextEditingController _ipController = TextEditingController();
  bool _isScanning = false;

  void _startScan() async {
    if (_ipController.text.isEmpty) return;

    setState(() => _isScanning = true);
    String result = await NmapService.scanNetwork(_ipController.text);
    setState(() => _isScanning = false);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ResultView(scanResult: result),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Nmap Scanner")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _ipController,
              decoration: const InputDecoration(
                labelText: "Masukkan IP Address",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isScanning ? null : _startScan,
              child: _isScanning
                  ? const CircularProgressIndicator()
                  : const Text("Mulai Scan"),
            ),
          ],
        ),
      ),
    );
  }
}
