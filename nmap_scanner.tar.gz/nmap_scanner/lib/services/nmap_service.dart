import 'dart:io';
import 'package:process_run/process_run.dart';

class NmapService {
  static Future<String> scanNetwork(String ip) async {
    try {
      ProcessResult result = await run('nmap', ['-sV', ip]);
      return result.stdout.toString();
    } catch (e) {
      return "Error saat menjalankan Nmap: $e";
    }
  }
}
