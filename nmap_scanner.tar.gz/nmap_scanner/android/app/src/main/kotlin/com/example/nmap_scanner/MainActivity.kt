package com.example.nmap_scanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
